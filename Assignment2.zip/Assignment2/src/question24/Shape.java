package question24;

class Shape {
    
    double length;

    
    Shape(double length)
    {
        this.length = length;
    }

   
    public void square() {
        double area = length * length;
        System.out.println("Area of Square = " + area);
    }

   
    void rectangle(double breadth) {
        double area = length * breadth;
        System.out.println("Area of Rectangle = " + area);
    }

    
    void circle() {
        double area = 3.14 * length * length;
        System.out.println("Area of Circle = " + area);
    }
}

 class test {
    public static void main(String[] args) {

       
        Shape obj = new Shape(5);

        // Calling methods
        obj.square();          // Square with side = 5
        obj.rectangle(4);      // Rectangle with length = 5 and breadth = 4
        obj.circle();          // Circle with radius = 5
    }
}