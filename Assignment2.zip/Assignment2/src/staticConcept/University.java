package staticConcept;

public class University {

	static String country="India";
	
	String universityName;
	
	University(String universityName){
		this.universityName=universityName;
	}
	
	public static void m1() {
	System.out.println("My Country Name is: "+country);
	}
	
	public void m2() {
		System.out.println("My Country Name is: "+country);
		System.out.println("My university Name is: "+universityName);
	}
	
	
	public static void main(String [] args) {
		
		University.m1();
		University b8 = new University("MSBTE");
		b8.m2();
		
		University b9 = new University("SPPU");
		b9.m2();
		
		
	}
}


