 package finalKeywordWithConstant;

public class GovernmentRules {

	final static double MAX_WORKING_HOURS = 8;
	
	
	
	public static void main(String [] args) {
		
		final static double MAX_WORKING_HOURS = 10;
	}
}
