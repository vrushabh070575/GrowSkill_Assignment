package constructorChaning;

public class Mall {

	Mall() {
		System.out.println("Welcome to the Mall");
	}

	Mall(int a) {
		this();
		System.out.println("Value passed: " + a);
	}
	
	public static void main(String [] args) {
		new Mall(25);
		
	}
}