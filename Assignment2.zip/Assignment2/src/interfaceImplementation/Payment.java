package interfaceImplementation;

public interface Payment {

	public void makePayment();

}

class UPI implements Payment {

	public void makePayment() {
		System.out.println("Payment Successful using UPI");
	}

}

class CreditCard implements Payment {

	public void makePayment() {

		System.out.println("Payment Successful using Creditcard");
	}

}

class test {
	public static void main(String[] args) {
		Payment a1 = new UPI();
		a1.makePayment();
		

		Payment a2 = new CreditCard();
		a2.makePayment();

	}
}
