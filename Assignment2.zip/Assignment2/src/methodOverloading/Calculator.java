package methodOverloading;

public class Calculator {

	void add(int a, int b) {
		System.out.println("First add Method with values  " + a + " " + b);
	}

	void add(double a, double b) {
		System.out.println("Second add Method with values  " + a + " " + b);
	}

	public static void main(String[] args) {
		Calculator a1 = new Calculator();
		a1.add(20, 30);
		a1.add(30.5, 41.5);
	}
}
