package finalKeyword;

public class Bank {

	final String IFSC = "UTBI00012345";
	
	final public void showIFSC() {
		System.out.println("IFSC value is  "+ IFSC);
	}
	
}

class HDFCBank extends Bank{
	
	//CompileTime Error Shown
	public void showIFSC() {
		System.out.println("Final Declared method cannot be override");
	}
	
	public static void main (String [] args) {
		HDFCBank a6= new HDFCBank ();
		a6.showIFSC();
	}
}
