package polymorphismUpcasting;

public class Camera {

	public void capture() {
		System.out.println("Camera Capture Method Calling");
	}
}

class DSLCamera extends Camera {
	public void capture() {
		System.out.println("DSLCamera 'Capture' Method Calling");
	}
}

class test{
	public static void main (String [] args) {
		Camera b7 = new DSLCamera();
		b7.capture();
	}
}
