package abstractClassRealUsage;

public abstract class Employee {

	public abstract void calculateSalary();

}

class FullTimeEmployee extends Employee {

	public void calculateSalary() {

		System.out.println("FullTimeEmployee class method calling:");
	}

}

class PartTimeEmployee extends Employee

{
	public void calculateSalary() {

		System.out.println("PartTimeEmployee Class method calling:");
	}

}

class test {

	public static void main(String[] args) {
		Employee b4 = new PartTimeEmployee();
		b4.calculateSalary();

		Employee b5 = new FullTimeEmployee();
		b5.calculateSalary();
	}
}