package inheritanceMultilevel;

public class Device {

	public void start() {
		System.out.println("Start Method is shown");
	}

}

class Mobile extends Device {

	public void calling() {
		System.out.println("calling Method is shown");
	}
}

class SmartPhone extends Mobile {
	public void internet() {
		System.out.println("internet Method is shown");
	}
}

class test {
	public static void main(String args[]) {
		SmartPhone a9 = new SmartPhone();
		a9.start();
		a9.calling();
		a9.internet();
	}
}
