package inheritanceMethodOverriding;

public class Vehicle {

	public void fuelType() {
		System.out.println("Runs on fuel");
	}
	
}

	class ElectricCar {
		public void fuelType() {
			System.out.println("Runs on electricity");
		}

	}

	 class test {

		public static void main(String[] args) {

			ElectricCar a1 = new ElectricCar();
			a1.fuelType();

			Vehicle a2 = new Vehicle();
			a2.fuelType();
		}
	}

