package methodOverloadingBankScenario;

public class LoanCalculator {

	public void calculateLoan(int amount) {

		System.out.println("Total Loan Amount is: " + amount);
	}

	public void calculateLoan(int amount, double interestRate) {
		
		System.out.println("Total Loan Amount is: " + amount);
		System.out.println("Interest Rate is: " + amount);
		
	}

	public static void main(String[] args) {

		LoanCalculator b2 = new LoanCalculator();
		b2.calculateLoan(45000);
		b2.calculateLoan(85000, 7.90);
	}
}