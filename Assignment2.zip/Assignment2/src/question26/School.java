package question26;

public class School {

	String name;
	String address;
	int strength;

	School(String name, String address) {

		this.name = name;
		this.address = address;
	}

	School(String name, String address, int strength) {
		this.name = name;
		this.address = address;
		this.strength = strength;
	}

	public void m5() {
		System.out.println(name + " " + address + " " + strength);
	}

	public static void main(String[] args) {
		School b11 = new School("NESK", "Kolkata");
		b11.m5();

		School b12 = new School("SPPU", "MUMBAI", 1000);
		b12.m5();

	}
}
