package encapsulation;

public class Employee {

	private String empId;
	private String empName;
	private double salary;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	void displayMethods(){
		System.out.println("Employees Details are " + "\n" + empId + " "  + empName +" " + salary);
	}

	public static void main(String[] args) {
		
		Employee obj = new Employee();
		obj.setEmpId("T015");
		obj.setEmpName("JOHN");
		obj.setSalary(87453.90);
		
		obj.displayMethods();
	}
	

}
