package interfaceWithMultipleImplementation;

public interface Transport {

	public void booking();
}

class Bus implements Transport {

	public void booking() {

		System.out.println("Bus class Method calling");

	}

}

class Flight implements Transport {

	public void booking() {

		System.out.println("Flight class Method calling");

	}

}

class test {

	public static void main(String[] args) {

		Transport b6 = new Bus();
		b6.booking();

		Transport b7 = new Flight();
		b7.booking();

	}
}