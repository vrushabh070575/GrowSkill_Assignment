package polymorphismDyanamicBinding;

public class Shape {

	public void area() {

	}

}

class Rectangle extends Shape {
	public void area() {
	
		System.out.println("Area of rectangle");
	}
}

class Circle extends Shape {
	public void area() {
		System.out.println("Area of Circle");
	}
}

class test {

	public static void main(String[] args) {
		Shape a5 = new Rectangle();
		a5.area();
		
		Shape a6 = new Circle();
		a6.area();

	}

}
