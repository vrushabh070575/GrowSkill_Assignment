package question25;

public class School {

	String name="NESK";
	
	School(){
		
	System.out.println("name of school is: "+ name);
	}
	
	public void schoollocation() {
		
		
		System.out.println("This School is based out of Kolkata");
	}
	
	public static void main(String [] args) {
		
		School b10= new School();
		b10.schoollocation();
		
	}
	
}
