package hierarchicalInheritance;

public class Course {

	public void coureInfo() {
		System.out.println("CourseInfo Method Display");
	}
}

class Science extends Course {
	public void m1() {
		System.out.println("these is m1 method");
	}

}

class Commerce extends Course {
	public void m2() {
		System.out.println("these is m2 method");
	}
}

class Arts extends Course {
	public void m3() {
		System.out.println("these is m3 method");
	}
}

class test {

	public static void main(String[] args) {
		Arts b1 = new Arts();
		b1.m3();
		b1.coureInfo();
		Commerce b2 = new Commerce();
		b2.m2();
		b2.coureInfo();
		Science b3 = new Science();
		b3.m1();
		b3.coureInfo();
	}
}