package abstraction;

public abstract class Animal {

	abstract void sound();
}

class dog extends Animal {

	void sound() {
		System.out.println("BHO BHO");
	}

}

class cat extends Animal {

	void sound() {

		System.out.println("MEO MEO");
	}

}

class test {
	public static void main(String[] args) {
		cat a1 = new cat();
		a1.sound();
		
		dog a2 = new dog();
		a2.sound();
	}
}