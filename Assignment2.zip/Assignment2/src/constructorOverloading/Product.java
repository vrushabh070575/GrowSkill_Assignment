package constructorOverloading;

public class Product {

	int productId;
	String ProductName;
	Double Price;

	Product() {
		System.out.println("Product Created");
	}

	Product(int productId, String ProductName, Double Price) {
		this.productId = productId;
		this.ProductName = ProductName;
		this.Price = Price;

	}

	public void displayProduct() {
		System.out.println("Below is Product Details" + "\n" + " " + productId + " " + ProductName + " " + Price);
	}

	public static void main(String[] args) {
		new Product();
		Product a1 = new Product(1234, "SOAP", 75.00);
		a1.displayProduct();

	}

}
