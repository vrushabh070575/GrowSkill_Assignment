package superKeyword;

class Person {

    Person() {
        System.out.println("Person Created");
    }
}

class Student extends Person {

    Student() {
        super();
        System.out.println("Student Created");
    }

    public static void main(String[] args) {
        new Student();
    }
}