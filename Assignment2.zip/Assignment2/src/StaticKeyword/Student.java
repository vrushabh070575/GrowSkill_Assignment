package StaticKeyword;

public class Student {

	static String collegeName = "SPPU";
	int rollNo;
	String name;
	
	Student(String n,int r){
		rollNo=r;
		name=n;
	}

	public void m1() {
		System.out.println("Name: "+name + " " +"RollNo: "+ rollNo + " " +"CollegeName: "+ collegeName);
	}

	public static void main(String args[]) {
		
		Student a7 = new Student("user1",1);
		a7.m1();
		Student a8 = new Student("user2",2);
		a8.m1();
		Student a9 = new Student("user3",3);
		a9.m1();
		
	}
}
