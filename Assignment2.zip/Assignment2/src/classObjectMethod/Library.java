package classObjectMethod;

public class Library {
	String libraryName;

	Library() {
		System.out.println("Welcome to the Library!");
	}

	public void showLocation() {
		System.out.println("This library is located in Mumbai");
	}

	public static void main(String[] args) {
		Library a8 = new Library();
		a8.showLocation();
	}
}
