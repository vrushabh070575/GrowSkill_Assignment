package encapsulationAndLogicValidation;

public class Account {

	private String accountHolderName;
	private double balance;

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {

		if (balance < 0) {
			System.out.println("Warning: Balance cannot be negative!");
		}

		else {
			this.balance = balance;
		}
	}
	
	public static void main (String [] args) {
		Account acc = new Account();
		acc.setAccountHolderName("user1");
		acc.setBalance(-1000);		
		System.out.println("AccountHolderName:  "+ acc.getAccountHolderName());
		System.out.println("Accountbalance  "+acc.getBalance());
		
	System.out.println("**********************************************************");	
		Account acc1 = new Account();
		acc1.setAccountHolderName("user1");
		acc1.setBalance(5000);
		
		System.out.println("AccountHolderName:  "+ acc1.getAccountHolderName());
		System.out.println("Accountbalance:  "+acc1.getBalance());
		
	}

}
