package methodOverridingWithSuper;

public class Hospital {

	public void emergencyService() {
		System.out.println("Hospital: these is parent class method");
	}
}

class CityHospital extends Hospital {

	public void emergencyService() {
		super.emergencyService();
		System.out.println("CityHospital: Providing advanced emergency services");
	}

	public static void main(String[] args) {
		CityHospital b3 = new CityHospital();
		b3.emergencyService();
	}
}
